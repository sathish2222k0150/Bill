<?php
require_once 'sidebar.php';
require_once 'config.php'; // Your PDO connection file

// --- DATA FETCHING ---

$stats = [];

// Card 1: Total Invoices (Sales)
$stmt = $pdo->prepare("
    SELECT COUNT(id) as count, COALESCE(SUM(ii.grand_total), 0) as total
    FROM invoices i
    JOIN (SELECT invoice_id, SUM(grand_total) as grand_total FROM invoice_items GROUP BY invoice_id) ii ON i.id = ii.invoice_id
    WHERE i.invoice_type IN ('Invoice','Tax Invoice','Supplementary','Tax Supplementary')
");
$stmt->execute();
$stats['invoices'] = $stmt->fetch(PDO::FETCH_ASSOC);

// Card 2: Total Labour Invoices
$stmt = $pdo->prepare("SELECT COUNT(id) as count, COALESCE(SUM(grand_total), 0) as total FROM labour_invoices");
$stmt->execute();
$stats['labour_invoices'] = $stmt->fetch(PDO::FETCH_ASSOC);

// Card 3: Total Purchase Invoices
$stmt = $pdo->prepare("SELECT COUNT(id) as count, COALESCE(SUM(total_amount + total_cgst + total_sgst), 0) as total FROM purchases");
$stmt->execute();
$stats['purchases'] = $stmt->fetch(PDO::FETCH_ASSOC);

// Card 4: Total Customers
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM customers");
$stmt->execute();
$stats['customers_count'] = $stmt->fetchColumn();

// Card 5: Total Receipts (Placeholder - No 'receipts' table in schema)
// Once you create a 'receipts' table, you can add the query here.
$stats['receipts'] = ['count' => 0, 'total' => 0.00];

// Card 6: Low Stock Products count
$stmt = $pdo->prepare("SELECT COUNT(*) as count FROM products WHERE quantity <= 5");
$stmt->execute();
$stats['low_stock_count'] = $stmt->fetchColumn();


// --- CHART DATA ---

// Monthly Sales (Actual Invoices, not Estimates)
$stmt = $pdo->prepare("
    SELECT MONTH(i.invoice_date) as month, COALESCE(SUM(ii.grand_total), 0) as total
    FROM invoices i
    JOIN invoice_items ii ON i.id = ii.invoice_id
    WHERE YEAR(i.invoice_date) = YEAR(CURDATE())
    AND i.invoice_type IN ('Invoice','Tax Invoice','Supplementary','Tax Supplementary')
    GROUP BY month
");
$stmt->execute();
$monthlySales = $stmt->fetchAll(PDO::FETCH_ASSOC);


// --- TABLE DATA ---

// Combined Recent Activities (Last 10)
$stmt = $pdo->prepare("
    (SELECT
        i.invoice_type as type,
        i.invoice_number as number,
        c.customer_name as name,
        SUM(ii.grand_total) as amount,
        i.created_at as activity_date
     FROM invoices i
     JOIN invoice_items ii ON i.id = ii.invoice_id
     JOIN customers c ON i.customer_id = c.id
     GROUP BY i.id
    )
    UNION ALL
    (SELECT
        'Labour Invoice' as type,
        li.invoice_number as number,
        li.customer_name as name,
        li.grand_total as amount,
        li.created_at as activity_date
    FROM labour_invoices li
    WHERE li.invoice_number IS NOT NULL
    )
    UNION ALL
    (SELECT
        'Purchase' as type,
        p.bill_no as number,
        v.name as name,
        (p.total_amount + p.total_cgst + p.total_sgst) as amount,
        p.date as activity_date
    FROM purchases p
    JOIN vendors v ON p.vendor_id = v.vendor_id
    )
    -- Add UNION ALL for receipts here when table is available
    ORDER BY activity_date DESC
    LIMIT 10
");
$stmt->execute();
$recentActivities = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Low Stock Products (top 5 for alert and critical stock table)
$stmt = $pdo->prepare("
    SELECT id as product_id, product_name, quantity
    FROM products
    WHERE quantity <= 5
    ORDER BY quantity ASC
    LIMIT 5
");
$stmt->execute();
$lowStockProducts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="main-content">
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-12">
            <h2><i class="fas fa-tachometer-alt"></i> Dashboard</h2>
            <p class="text-muted">Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>! Here's your business overview.</p>
        </div>
    </div>

    <?php if ($stats['low_stock_count'] > 0): ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="alert alert-warning">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Stock Alert:</strong> <?php echo $stats['low_stock_count']; ?> product(s) are running low!
                    </div>
                    <a href="product/product-list.php" class="btn btn-sm btn-outline-dark">View All Products</a>
                </div>
                <div class="mt-2">
                    <?php foreach ($lowStockProducts as $product): ?>
                    <span class="badge bg-danger me-2 mb-1">
                        <?php echo htmlspecialchars($product['product_name']); ?>
                        (<?php echo $product['quantity']; ?> left)
                    </span>
                    <?php endforeach; ?>
                    <?php if ($stats['low_stock_count'] > 5): ?>
                    <span class="text-muted">+ <?php echo ($stats['low_stock_count'] - 5); ?> more...</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Six Cards in one row -->
    <div class="row mb-4">
        <div class="col-lg-2 col-md-4 mb-4">
            <div class="dashboard-card text-primary">
                <div class="card-icon"><i class="fas fa-file-invoice-dollar"></i></div>
                <h3><?php echo $stats['invoices']['count']; ?></h3>
                <p>Total Invoices</p>
                <small>₹<?php echo number_format($stats['invoices']['total'], 2); ?></small>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-4">
            <div class="dashboard-card text-secondary">
                <div class="card-icon"><i class="fas fa-hard-hat"></i></div>
                <h3><?php echo $stats['labour_invoices']['count']; ?></h3>
                <p>Labour Invoices</p>
                <small>₹<?php echo number_format($stats['labour_invoices']['total'], 2); ?></small>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-4">
            <div class="dashboard-card text-info">
                <div class="card-icon"><i class="fas fa-shopping-cart"></i></div>
                <h3><?php echo $stats['purchases']['count']; ?></h3>
                <p>Purchase Invoices</p>
                <small>₹<?php echo number_format($stats['purchases']['total'], 2); ?></small>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-4">
            <div class="dashboard-card text-success">
                <div class="card-icon"><i class="fas fa-users"></i></div>
                <h3><?php echo $stats['customers_count']; ?></h3>
                <p>Total Customers</p>
                <small>&nbsp;</small>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-4">
            <div class="dashboard-card text-warning">
                <div class="card-icon"><i class="fas fa-receipt"></i></div>
                <h3><?php echo $stats['receipts']['count']; ?></h3>
                <p>Total Receipts</p>
                <small>₹<?php echo number_format($stats['receipts']['total'], 2); ?></small>
            </div>
        </div>
        <div class="col-lg-2 col-md-4 mb-4">
            <div class="dashboard-card text-danger">
                <div class="card-icon"><i class="fas fa-box-open"></i></div>
                <h3><?php echo $stats['low_stock_count']; ?></h3>
                <p>Low Stock Items</p>
                <small>&nbsp;</small>
            </div>
        </div>
    </div>

    <!-- Row with chart and quick links -->
    <div class="row mb-4">
        <div class="col-lg-8 mb-4">
            <div class="chart-container" style="height: 350px;">
                <h5><i class="fas fa-chart-line"></i> Monthly Sales Revenue (Current Year)</h5>
                <canvas id="monthlySalesChart"></canvas>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
             <div class="chart-container h-100">
                <h5><i class="fas fa-link"></i> Quick Links</h5>
                <div class="d-grid gap-3">
                    <a href="step-1.php" class="btn btn-success btn-lg"><i class="fas fa-file-invoice fa-fw me-2"></i> Create Invoice</a>
                    <a href="labour/labour-invoice-create.php" class="btn btn-secondary btn-lg"><i class="fas fa-hard-hat fa-fw me-2"></i> Create Labour</a>
                    <a href="purchase/purchase-entry.php" class="btn btn-info btn-lg"><i class="fas fa-shopping-cart fa-fw me-2"></i> Create Purchase</a>
                    <a href="receipt/receipts.php" class="btn btn-warning btn-lg"><i class="fas fa-receipt fa-fw me-2"></i> Create Receipt</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activities & Low Stock -->
    <div class="row">
        <div class="col-lg-8 mb-4">
            <div class="table-container">
                <h5><i class="fas fa-clock"></i> Recent Activities</h5>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr><th>Type</th><th>Number</th><th>Customer/Vendor</th><th>Amount</th><th>Date</th></tr>
                        </thead>
                        <tbody>
                        <?php if (!empty($recentActivities)): ?>
                            <?php foreach ($recentActivities as $activity): ?>
                            <tr>
                                <td>
                                    <span class="badge
                                        <?php
                                            $type = strtolower($activity['type']);
                                            if (strpos($type, 'invoice') !== false) echo 'bg-primary';
                                            elseif (strpos($type, 'labour') !== false) echo 'bg-secondary';
                                            elseif (strpos($type, 'purchase') !== false) echo 'bg-info';
                                            else echo 'bg-dark';
                                        ?>">
                                        <?php echo htmlspecialchars($activity['type']); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($activity['number']); ?></td>
                                <td><?php echo htmlspecialchars($activity['name']); ?></td>
                                <td>₹<?php echo number_format($activity['amount'], 2); ?></td>
                                <td><?php echo date('M d, Y', strtotime($activity['activity_date'])); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="text-center">No recent activities found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-4 mb-4">
            <div class="table-container">
                <h5><i class="fas fa-exclamation-triangle text-warning"></i> Critical Stock</h5>
                <?php if ($lowStockProducts): ?>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead><tr><th>Product</th><th>Stock</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php foreach ($lowStockProducts as $product): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                            <td><span class="badge bg-<?php echo $product['quantity'] <= 2 ? 'danger' : 'warning'; ?>"><?php echo $product['quantity']; ?></span></td>
                            <td>
                                <a href="product/product-list.php" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i> Restock
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> All products are well stocked!
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const salesData = Array(12).fill(0);

    <?php foreach($monthlySales as $m): ?>
    salesData[<?php echo $m['month'] - 1; ?>] = <?php echo floatval($m['total']); ?>;
    <?php endforeach; ?>

    const salesChartCtx = document.getElementById('monthlySalesChart');
    if (salesChartCtx) {
        new Chart(salesChartCtx, {
            type: 'line',
            data: {
                labels: months,
                datasets: [{
                    label: 'Sales',
                    data: salesData,
                    borderColor: '#007bff',
                    backgroundColor: 'rgba(0, 123, 255, 0.1)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false, // Important for resizing chart in container
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₹' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
});
</script>

<?php require_once 'footer.php'; ?>
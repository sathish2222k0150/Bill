<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /test/index.php');
    exit;
}

// A flag to determine if we are viewing a saved invoice or a temporary preview.
$is_saved_view = false;
$invoice = null;
// --- MODIFIED: Initialize a variable for the date to be displayed ---
$display_date = date('Y-m-d'); 

// ===================================================================
// LOGIC FOR VIEWING A SAVED INVOICE (from Database)
// ===================================================================
if (isset($_GET['id'])) {
    $is_saved_view = true;
    $invoice_id = intval($_GET['id']);

    // Fetch the main invoice record to get customer_id and invoice_number
    $invoice_stmt = $pdo->prepare("SELECT * FROM invoices WHERE id = ?");
    $invoice_stmt->execute([$invoice_id]);
    $invoice = $invoice_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$invoice) {
        header('Location: step-1.php?error=invoice_not_found');
        exit;
    }

    $customer_id = $invoice['customer_id'];
    // --- MODIFIED: Get the date from the saved invoice record ---
    $display_date = $invoice['invoice_date'];

    // Fetch customer details from DB
    $stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
    $stmt->execute([$customer_id]);
    $customer = $stmt->fetch(PDO::FETCH_ASSOC);

    // Fetch saved invoice items from DB, joining with products table
    $items_stmt = $pdo->prepare(
        "SELECT p.product_name, ii.* 
         FROM invoice_items ii 
         JOIN products p ON ii.product_id = p.id 
         WHERE ii.invoice_id = ?"
    );
    $items_stmt->execute([$invoice_id]);
    $saved_items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Re-structure the items array to match the format used by the template
    $display_items = [];
    foreach ($saved_items as $item) {
        $display_items[] = [
            'product_name'        => $item['product_name'],
            'quantity'            => $item['quantity'],
            'price'               => ($item['quantity'] > 0) ? ($item['subtotal'] / $item['quantity']) : 0, // Calculate price per unit
            'cgst'                => $item['cgst_percent'],
            'sgst'                => $item['sgst_percent'],
            'reg_no'              => '' // This info is not stored per item, can be fetched if needed
        ];
    }

// ===================================================================
// LOGIC FOR PREVIEWING AN UNSAVED INVOICE (from Session)
// ===================================================================
} else {
    // Check if we have POST data from the add-products page.
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['product_id'])) {
        $customer_id = intval($_POST['customer_id']);
        // --- NEW: Capture the invoice date from the POST data ---
        $invoice_date = $_POST['invoice_date'] ?? date('Y-m-d');
        $display_date = $invoice_date; // Set it for display

        $invoice_items = [];
        $item_count = count($_POST['product_id']);
        
        for ($i = 0; $i < $item_count; $i++) {
            $invoice_items[] = [
                'product_id'          => $_POST['product_id'][$i],
                'product_name'        => $_POST['product_name'][$i],
                'quantity'            => floatval($_POST['quantity'][$i]),
                'price'               => floatval($_POST['price'][$i]),
                'cgst'                => isset($_POST['cgst']) ? floatval($_POST['cgst'][$i]) : 0,
                'sgst'                => isset($_POST['sgst']) ? floatval($_POST['sgst'][$i]) : 0,
                'reg_no'              => $_POST['reg_no'][$i] ?? '',
            ];
        }
        
        // --- MODIFIED: Store the invoice date in the session along with items ---
        $_SESSION['invoice_data'][$customer_id] = [
            'date'  => $invoice_date,
            'items' => $invoice_items
        ];

    } elseif (isset($_GET['customer_id'])) {
        $customer_id = intval($_GET['customer_id']);
        if (!isset($_SESSION['invoice_data'][$customer_id]) && !isset($_GET['status'])) {
            header('Location: step-1.php?error=no_session_data');
            exit;
        }
    } else {
        // If no ID or customer data, redirect unless showing a success message.
        if (!isset($_GET['status'])) {
            header('Location: step-1.php');
            exit;
        }
        // Allows the success modal to show on a clean page
        $customer = null;
        $display_items = [];
    }
    
    if (isset($customer_id)) {
        // Fetch data from session for display
        $display_items = $_SESSION['invoice_data'][$customer_id]['items'] ?? [];
        // --- NEW: Fetch the date from session for display ---
        $display_date = $_SESSION['invoice_data'][$customer_id]['date'] ?? date('Y-m-d');

        // Fetch customer details from DB
        $stmt = $pdo->prepare("SELECT * FROM customers WHERE id = ?");
        $stmt->execute([$customer_id]);
        $customer = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

// Final check for customer, redirect if something went wrong
if (!$customer && !isset($_GET['status'])) {
     header('Location: step-1.php?error=customer_not_found');
     exit;
}

// ===================================================================
// CALCULATIONS (works for both saved and previewed data)
// ===================================================================
$with_tax = ($customer && $customer['with_tax'] === 'Yes');
$subtotal = 0;
$total_cgst = 0;
$total_sgst = 0;

foreach ($display_items as $item) {
    $taxable_value = $item['quantity'] * $item['price'];
    $subtotal += $taxable_value;
    if ($with_tax) {
        $total_cgst += $taxable_value * ($item['cgst'] / 100);
        $total_sgst += $taxable_value * ($item['sgst'] / 100);
    }
}
$grand_total = $subtotal + $total_cgst + $total_sgst;
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Invoice Preview</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
  <style>
    body { background-color: #f8f9fa; }
    .invoice-container { max-width: 800px; margin: 40px auto; background: #fff; padding: 40px; border: 1px solid #ddd; box-shadow: 0 0 10px rgba(0,0,0,0.05); font-family: sans-serif; }
    .invoice-header { border-bottom: 2px solid #dee2e6; padding-bottom: 20px; margin-bottom: 30px; }
    .invoice-header .logo { font-size: 1.8rem; font-weight: bold; color: #dc3545; }
    .invoice-details { text-align: right; }
    .invoice-details h2 { margin: 0; font-size: 1.8rem; font-weight: bold; text-transform: capitalize;}
    .billing-details { margin-top: 30px; }
    .table-items th { background-color: #f8f9fa; }
    .totals-section { margin-top: 30px; }
    .totals-table { width: 100%; max-width: 350px; margin-left: auto; }
    .totals-table td { padding: 0.5rem; }
    .actions { margin-top: 40px; text-align: right; }
    @media print {
        .actions, .modal { display: none !important; }
        body { background-color: #fff; }
        .invoice-container { box-shadow: none; border: none; margin: 0 auto; max-width: 100%; }
    }
  </style>
</head>
<body>

<div class="invoice-container">
    <?php if ($customer): // Only show content if a customer is loaded ?>
    <div class="row invoice-header align-items-center">
        <div class="col-6">
            <div class="logo">SDS Automotive</div>
            <div>9842365406, 9952513032</div>
            <div>sdsmotors2019@gmail.com</div>
        </div>
        <div class="col-6 invoice-details">
            <h2><?= htmlspecialchars($customer['invoice_type'] ?? 'Invoice') ?></h2>
            <!-- --- MODIFIED: Display the date variable in a user-friendly format --- -->
            <div><strong>Date:</strong> <?= date('d-m-Y', strtotime($display_date)) ?></div>
            <div><strong>Invoice #:</strong> <?= $is_saved_view ? htmlspecialchars($invoice['invoice_number']) : '[Pending Save]' ?></div>
        </div>
    </div>
    
    <div class="row billing-details">
        <div class="col-7">
            <strong>Billed To</strong>
            <address class="mt-2 ps-2">
                <strong><?= htmlspecialchars($customer['customer_name']) ?></strong><br>
                <?= htmlspecialchars($customer['customer_address']) ?><br>
                <?= htmlspecialchars($customer['customer_contact']) ?><br>
                <strong>Reg No:</strong> <?= htmlspecialchars($customer['reg_no']) ?><br>
                <strong>GST:</strong> <?= htmlspecialchars($customer['gst_number']) ?>
            </address>
        </div>
        <div class="col-5 text-end">
            <strong>Business Address</strong>
            <address class="mt-2">
                KARAIKADU, SIPCOT POST<br>
                CUDDALORE TO VIRUDHACHALAM MAIN ROAD<br>
                CUDDALORE - 607005
            </address>
        </div>
    </div>

    <?php if (!empty($display_items)): ?>
    <table class="table table-bordered mt-4 table-items">
        <thead class="table-secondary">
            <tr class="text-center">
                <th style="width:5%;">S.No</th>
                <th>Description</th>
                <th style="width:8%;">Qty</th>
                <th style="width:12%;">Price (₹)</th>
                <?php if ($with_tax): ?>
                <th style="width:10%;">CGST %</th>
                <th style="width:10%;">SGST %</th>
                <?php endif; ?>
                <th style="width:15%;">Total (₹)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($display_items as $index => $item): ?>
            <tr>
                <td class="text-center"><?= $index + 1 ?></td>
                <td><?= htmlspecialchars($item['product_name']) ?></td>
                <td class="text-center"><?= $item['quantity'] ?></td>
                <td class="text-end"><?= number_format($item['price'], 2) ?></td>
                <?php if ($with_tax): ?>
                <td class="text-center"><?= $item['cgst'] ?>%</td>
                <td class="text-center"><?= $item['sgst'] ?>%</td>
                <?php endif; ?>
                <td class="text-end"><?= number_format($item['quantity'] * $item['price'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="row totals-section">
        <div class="col-7">
        </div>
        <div class="col-5">
            <table class="table totals-table">
                <tbody>
                    <tr>
                        <td>Subtotal</td>
                        <td class="text-end"><?= number_format($subtotal, 2) ?></td>
                    </tr>
                    <?php if ($with_tax): ?>
                    <tr>
                        <td>CGST</td>
                        <td class="text-end"><?= number_format($total_cgst, 2) ?></td>
                    </tr>
                     <tr>
                        <td>SGST</td>
                        <td class="text-end"><?= number_format($total_sgst, 2) ?></td>
                    </tr>
                    <?php endif; ?>
                    <tr class="fw-bold table-secondary">
                        <td>Grand Total</td>
                        <td class="text-end"><?= number_format($grand_total, 2) ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="actions mt-5">
        <?php if ($is_saved_view): ?>
            <!-- Buttons for a SAVED invoice -->
            <button onclick="window.print()" class="btn btn-info"><i class="fas fa-print"></i> Print Invoice</button>
            <a href="step-1.php" class="btn btn-success"><i class="fas fa-plus"></i> Create New Invoice</a>
        <?php elseif (!empty($display_items)): ?>
            <!-- Buttons for an UNSAVED invoice preview -->
            <a href="invoice-add-products.php?customer_id=<?= $customer_id ?>" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Edit</a>
            <button onclick="window.print()" class="btn btn-info"><i class="fas fa-print"></i> Print</button>
            <form action="save-invoice.php" method="POST" class="d-inline">
                <input type="hidden" name="customer_id" value="<?= $customer_id ?>">
                <!-- --- NEW: Hidden input to pass the date to the save script --- -->
                <input type="hidden" name="invoice_date" value="<?= htmlspecialchars($display_date) ?>">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Confirm & Save Invoice</button>
            </form>
        <?php else: ?>
            <!-- Message shown after saving, before redirecting to view -->
            <div class="alert alert-info mt-4">This invoice has been saved or cleared.</div>
            <a href="step-1.php" class="btn btn-success"><i class="fas fa-plus"></i> Create New Invoice</a>
        <?php endif; ?>
    </div>
    <?php endif; // End of check for loaded customer ?>
</div>

<!-- Success Modal -->
<div class="modal fade" id="successModal" tabindex="-1" aria-labelledby="successModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="successModalLabel">Success!</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        <i class="fas fa-check-circle fa-4x text-success mb-3"></i>
        <p class="fs-5">The invoice has been saved successfully!</p>
      </div>
      <div class="modal-footer justify-content-center">
        <a href="preview.php" id="viewInvoiceBtn" class="btn btn-primary"><i class="fas fa-eye"></i> View Saved Invoice</a>
        <a href="step-1.php" class="btn btn-secondary"><i class="fas fa-plus"></i> Create New Invoice</a>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('status') === 'success') {
        const invoiceId = urlParams.get('invoice_id');
        const viewBtn = document.getElementById('viewInvoiceBtn');
        if (invoiceId && viewBtn) {
            // This is the key change: it correctly points to this same file with the 'id' parameter
            viewBtn.href = 'preview.php?id=' + invoiceId;
        }
        const successModal = new bootstrap.Modal(document.getElementById('successModal'));
        successModal.show();
    }
});
</script>

</body>
</html>